package org.EchoStarAirlines;

public class Electric {
}
