package org.EchoStarAirlines;

public class Flight {
}
