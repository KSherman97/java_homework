package com.ShermanKyle;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Scanner;

public class Dictionary {
    private String name;
    private HashMap<String, String> d;

    private static String dictionaryFile;
    private String sourceFile;
    private String translationFile;

    public Dictionary(){
        name = "no name";
        d = new HashMap<String, String>();
    }

    public Dictionary(String name){
        this.name = name;
        d = new HashMap<String, String>();
    }

    public void train(){
        int ct = 0;
        Scanner in = new Scanner(System.in);
        while (true){
            System.out.printf("Key:");
            String key = in.nextLine();
            if(key.isEmpty()) {
                System.out.print(this);
                break;
            }
            System.out.printf("Value:");
            String value = in.nextLine();
            this.d.put(key, value);
        }
    }

    public String toString(){
        String result = "Dictionary " + this.name + " \n";

        for (String key : this.d.keySet()) {
            String value = this.d.get(key);
            //System.out.println(key + ":" + value);
            result = result.concat(key + ":" + value +" \n") ;
        }
        return result;
    }

    public void dump(){
        System.out.print(this);
    }

    public String translateSentence(String original){
        String result = "";
        for(String word : original.split("\\w+")){
            String trans = this.translateWord(word);
            result = result.concat(trans + " ");
        }
        return result;
    }

    public String translateScanSentence(String sent){
        Scanner ss = new Scanner(sent).useDelimiter("\\W+");
        String result = "";
        while (ss.hasNext()){
            String word = ss.next();
            String trans = this.translateWord(word);
            result = result.concat(trans+" ");
        }
        return result;
    }

    public String translateWord(String original){
        if(this.d.containsKey(original)){
            return this.d.get(original);
        }

        return original;
    }
}
