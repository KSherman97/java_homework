package Sherman.Kyle;

public class CClass extends BClass {
    // initialize variables

    //constructors
    public CClass(){

    }

    // getters and setters

    // methods
    @Override
    public Integer f(){
        return 1;
    }

    @Override
    public String string(){
        return "CClass";
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("CClass{");
        sb.append("id=").append(id);
        sb.append(", fi=").append(fi);
        sb.append('}');
        return counter + sb.toString();
    }
}


