// interface class

package Sherman.Kyle;

public interface AInterface {
    public Integer f();
    public String string();
}
