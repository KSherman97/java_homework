package Sherman.Kyle;

public class DClass extends BClass {
    // initialize any variables

    // constructor

    // getters and setters

    // methods
    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("DClass{");
        sb.append("id=").append(id);
        sb.append(", fi=").append(fi);
        sb.append('}');
        return counter + sb.toString();
    }
}
