// Kyle Sherman
// In Class for 12/14/2017

package Sherman.Kyle;

import com.sun.corba.se.spi.transport.CorbaContactInfoList;

public class Main {
    public static int f(int i){ return i=1; }
    public static Integer f(Integer i){ return i = 1; }
    public static StringBuffer f(StringBuffer s) { return s.append("STRING");}

    public static void main(String[] args) {
	    // write your code here
        // 1) Variables
        // 2) Constructors
        // 3) Getters / Setters
        // 4) Methods
        int i = 0;
        Integer io = 0;
        StringBuffer s = new StringBuffer("0");

        f(i);
        f(io);
        f(s);

        System.out.println(i);
        System.out.println(io);
        System.out.println(s);

        //CClass[] cclass = new CClass[10];
        CClass[] cclass = {new CClass(), new CClass(), new CClass()};
        DClass[] dclass = {new DClass(), new DClass()};
        BClass[] bclass = new BClass[10];

        System.out.println(cclass[0]);
        System.out.println(bclass[0]);
        bclass[0] = cclass[0]; // set the 0 index in the b array to the same value of the 0 index for the c array
        // list / array / collection of different types
        System.out.print(bclass[0]);

        for(int index=0; index < cclass.length; index++){
            System.out.println(cclass[index]);
        }
    }
}