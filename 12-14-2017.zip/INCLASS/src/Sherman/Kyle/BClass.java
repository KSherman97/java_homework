package Sherman.Kyle;

public class BClass implements AInterface {
    // ===== initialize variables =====
    static Integer counter = 0;
    Integer id;
    static { counter = 0; } // Static Initializer
    final Integer fi = 5;

    // ===== constructors =====
    public BClass(){
        counter++;
        this.id=counter; // this will make each child class have their own id number with counter :)
    }

    // ===== overrides =====

    // ===== methods =====
    @Override
    public Integer f(){
        return 1;
    }

    @Override
    public String string(){
        return "BClass";
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("BClass{");
        sb.append("id=").append(id);
        sb.append(", fi=").append(fi);
        sb.append('}');
        return counter + sb.toString();
    }
}